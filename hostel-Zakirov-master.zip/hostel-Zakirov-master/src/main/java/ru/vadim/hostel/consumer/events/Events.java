package ru.vadim.hostel.consumer.events;

public enum Events {
    APARTMENT, CATEGORY, GUEST, USER;
}
